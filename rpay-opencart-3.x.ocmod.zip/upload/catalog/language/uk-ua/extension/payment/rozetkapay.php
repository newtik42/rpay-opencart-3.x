<?php
$_['text_title'] = 'Оплата через Visa|Mastercard|GooglePay|ApplePay (RozetkaPay)';
$_['button_pay'] = 'Перейти до оплати';

$_['button_pay_holding'] = 'Перейти до оплати (holding)';

$_['test_mode'] = 'Тестовий режим';

